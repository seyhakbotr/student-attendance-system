<script setup lang="ts">
import AuthenticatedLayout from "@/Layouts/AuthenticatedLayout.vue";

import {
    Card,
    CardContent,
    CardDescription,
    CardFooter,
    CardHeader,
    CardTitle,
} from "@/Components/ui/card";
import { ref } from "vue";
import { Input } from "@/Components/ui/input";
import { Label } from "@/Components/ui/label";
import { Button } from "@/Components/ui/button";
import { useVirtualList } from "@vueuse/core";
interface Classrooms {
    id: number;
    name: string;
    created_at: string;
    room_number: number;
    updated_at: string;
}
const props = defineProps<{
    classrooms: Classrooms[];
}>();
const { list, containerProps, wrapperProps } = useVirtualList(
    props.classrooms,
    {
        itemHeight: 140,
    },
);
</script>

<template>

    <Head title="Classroom" />

    <AuthenticatedLayout>
        <template #header>
            <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
                Classroom
            </h2>
        </template>
        <h1>Hello Class</h1>
        <div v-bind="containerProps" class="h-screen">
            <div v-bind="wrapperProps">
                <div class="grid grid-cols-3 gap-6">
                    <!-- Loop through classrooms and generate cards -->
                    <Card v-for="classroom in list" :key="classroom.data.id" class="w-[350px] h-full">
                        <CardHeader>
                            <CardTitle>{{ classroom.data.name }}</CardTitle>
                            <CardDescription v-if="classroom.data.room_number">Room:
                                {{
                                    classroom.data.room_number
                                }}</CardDescription>
                            <CardDescription v-else>
                                No desginated room numbers
                            </CardDescription>
                        </CardHeader>
                        <CardContent> </CardContent>
                        <CardFooter class="flex justify-between px-6 pb-6">
                            <Button variant="outline"> Cancel </Button>
                            <Button>Deploy</Button>
                        </CardFooter>
                    </Card>
                </div>
            </div>
        </div>
    </AuthenticatedLayout>
</template>
