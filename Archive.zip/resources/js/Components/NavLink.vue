<script setup lang="ts">
import { computed } from 'vue';
import { Link } from '@inertiajs/vue3';

const props = defineProps<{
    href: string;
    active?: boolean;
}>();

const classes = computed(() =>
    props.active
        ? 'flex items-center gap-3 rounded-lg bg-muted px-3 py-2 bg-purple-600 text-white transition-all hover:text-secondary'
        : 'flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary'
);
</script>

<template>
    <Link :href="href" :class="classes">
        <slot />
    </Link>
</template>
