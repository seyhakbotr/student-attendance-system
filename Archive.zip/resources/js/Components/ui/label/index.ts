export { default as Label } from './Label.vue'
