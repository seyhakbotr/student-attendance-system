<?php

namespace Database\Factories;

use App\Models\Classroom;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Course>
 */
class CourseFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'name' => $this->faker->unique()->randomElement(['Math', 'English', 'Science', 'Khmer', 'Japanese']), // Pre-generated course names
            'classroom_id' => Classroom::factory()->create()->id, // Create and associate with a classroom
        ];
    }
}
