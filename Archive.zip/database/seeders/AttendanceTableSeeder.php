<?php

namespace Database\Seeders;

use App\Models\Attendance;
use App\Models\Classroom;
use App\Models\Course;
use App\Models\Student;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class AttendanceTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Retrieve students, classrooms, and pre-generated courses
        $students = Student::all();
        $classrooms = Classroom::all();
        $courseNames = ['Math', 'English', 'Science', 'Khmer', 'Japanese']; // Pre-generated course names
        $courses = Course::whereIn('name', $courseNames)->get();

        // Define the schedule
        $schedule = [
            'Monday' => 'Math',
            'Tuesday' => 'English',
            'Wednesday' => 'Science',
            'Thursday' => 'Khmer',
            'Friday' => 'Japanese'
            // Add more days and courses as needed
        ];

        // Iterate over students and schedule to create attendance records
        foreach ($students as $student) {
            foreach ($schedule as $day => $courseName) {
                // Retrieve the course by name
                $course = $courses->where('name', $courseName)->first();
                if ($course) {
                    // Randomly select a classroom
                    $classroom = $classrooms->random();

                    // Create attendance record
                    Attendance::create([
                        'student_id' => $student->id,
                        'course_id' => $course->id,
                        'classroom_id' => $classroom->id,
                        'date' => now()->next($day),
                        'attended' => rand(0, 1) ? 'present' : 'absent',
                    ]);
                } else {
                    // Print error message if course not found
                    echo "Course '$courseName' not found.\n";
                }
            }
        }
    }
}
